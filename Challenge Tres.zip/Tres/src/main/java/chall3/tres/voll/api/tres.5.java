package med.voll.api.domain.medico;

public enum Especialidad {
    ORTOPEDIA,
    CARDIOLOGIA,
    GINECOLOGIA,
    PEDIATRIA
}
